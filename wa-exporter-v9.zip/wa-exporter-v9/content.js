// content.js — WhatsApp Web Group Exporter v9
// Based on real DOM debug: header has group name as first text node,
// subtitle span[title] contains ALL member phone numbers comma-separated.
// Chat list rows use different selectors (no cell-frame-container).

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Extract group name from #main header ──────────────────────────────────────
// The group name appears as plain text (first line) in the header.
// The subtitle span[title] contains the comma-separated member list.
function getOpenGroupName() {
  const header = document.querySelector('#main header');
  if (!header) return null;

  // Walk all spans — group name is a short text span, NOT the one with phone numbers
  const spans = [...header.querySelectorAll('span')].filter(s => {
    const txt = (s.getAttribute('title') || s.innerText || '').trim();
    // Skip spans that are mostly phone numbers
    if (!txt || txt.length < 2) return false;
    if (/^(\+?[\d\s,+]{10,})/.test(txt)) return false; // starts with phone list
    return true;
  });

  // The group name span is usually the first short span with actual text
  for (const s of spans) {
    const txt = (s.getAttribute('title') || s.innerText || '').trim();
    if (txt && txt.length > 1 && txt.length < 200 && !/^\+?[\d]/.test(txt)) {
      return txt;
    }
  }

  // Fallback: first line of header text
  const headerText = header.innerText.trim().split('\n')[0].trim();
  if (headerText && !/^\+/.test(headerText)) return headerText;

  return null;
}

// ── Extract contacts from the subtitle span[title] in #main header ────────────
// The subtitle span title="..." contains all member phone numbers comma-separated
function extractFromHeaderSubtitle() {
  const header = document.querySelector('#main header');
  if (!header) return null;

  // Find the span whose title is a long comma-separated list of phone numbers
  const spans = [...header.querySelectorAll('span[title]')];
  for (const span of spans) {
    const title = span.getAttribute('title') || '';
    // Check if it's a phone number list (contains multiple +254... numbers)
    const phones = title.split(',').map(p => p.trim()).filter(p => /^\+?[\d][\d\s\-]{6,}$/.test(p.replace('You','')));
    if (phones.length >= 2) {
      // This is the member list — parse all numbers
      const contacts = phones
        .filter(p => p && p !== 'You' && /\d/.test(p))
        .map(p => ({ name: '', phone: p.trim() }));
      return contacts.length > 0 ? contacts : null;
    }
  }
  return null;
}

// ── SCAN: build group list from left panel ────────────────────────────────────
function scanGroups() {
  const results = [];
  const seen = new Set();

  // 1. Currently open group
  const currentName = getOpenGroupName();
  if (currentName) {
    seen.add(currentName);
    results.push({ title: currentName, isGroup: true, current: true });
  }

  // 2. Left panel — try multiple row selectors since cell-frame-container may not exist
  const leftPane = document.querySelector('#pane-side');
  if (!leftPane) return results;

  // Try various selectors WhatsApp uses
  const rowSelectors = [
    '[data-testid="cell-frame-container"]',
    '[role="listitem"]',
    '[tabindex="-1"]',
    'div[class*="focusable"]',
    'div[class*="_ak8l"]', // common WA class pattern
  ];

  let rows = [];
  for (const sel of rowSelectors) {
    const found = [...leftPane.querySelectorAll(sel)];
    if (found.length > 0) { rows = found; break; }
  }

  // Fallback: find divs that contain a short text span (chat name) + longer text (subtitle)
  if (rows.length === 0) {
    rows = [...leftPane.querySelectorAll('div')].filter(div => {
      // Must be a direct-ish child of pane-side, have click behavior
      const txt = div.innerText?.trim();
      return txt && txt.length > 2 && txt.length < 500 &&
             div.getAttribute('tabindex') !== null &&
             div.children.length > 0 && div.children.length < 10;
    });
  }

  for (const row of rows) {
    // Get the first short text line as the chat title
    const allSpans = [...row.querySelectorAll('span')].filter(s => {
      const t = (s.getAttribute('title') || s.innerText || '').trim();
      return t.length > 1 && t.length < 100 && !/^\+?[\d\s,]{7,}/.test(t);
    });

    let title = '';
    for (const s of allSpans) {
      const t = (s.getAttribute('title') || s.innerText || '').trim();
      if (t && t.length > 1 && t.length < 80 && !/^\+/.test(t)) {
        title = t; break;
      }
    }

    if (!title || seen.has(title)) continue;
    if (/^(Locked chats|Archived|Status)$/i.test(title)) continue;

    seen.add(title);

    const isGroup =
      !!row.querySelector('[data-testid="default-group"]') ||
      !!row.querySelector('[data-icon="group"]') ||
      (row.innerText || '').split('\n').some(l => /\d+\s*(participants?|members?)/i.test(l));

    results.push({ title, isGroup, current: false });
  }

  results.sort((a,b) => a.current ? -1 : b.current ? 1 : (b.isGroup - a.isGroup));
  return results;
}

// ── OPEN CHAT ─────────────────────────────────────────────────────────────────
async function openChat(title) {
  if (getOpenGroupName() === title) return true;

  const leftPane = document.querySelector('#pane-side');
  if (!leftPane) return false;

  // Find and click the row whose first short span matches the title
  const allDivs = [...leftPane.querySelectorAll('div[tabindex="-1"], [role="listitem"]')];
  for (const div of allDivs) {
    const spans = [...div.querySelectorAll('span')].filter(s => {
      const t = (s.getAttribute('title') || s.innerText || '').trim();
      return t.length > 1 && t.length < 100 && !/^\+/.test(t);
    });
    for (const s of spans) {
      const t = (s.getAttribute('title') || s.innerText || '').trim();
      if (t === title) {
        div.scrollIntoView({ block: 'center' });
        await sleep(200);
        div.click();
        await sleep(2000);
        return true;
      }
    }
  }
  return false;
}

// ── OPEN INFO PANEL ───────────────────────────────────────────────────────────
async function openInfoPanel() {
  if (document.querySelector('[data-testid="contact-info-drawer"]')) return true;
  const header = document.querySelector('#main header');
  if (header) {
    header.click();
    await sleep(2000);
  }
  return !!document.querySelector('[data-testid="contact-info-drawer"]');
}

// ── MAIN EXTRACT FUNCTION ─────────────────────────────────────────────────────
async function extractFromGroup(title) {
  // STRATEGY 1: Extract directly from header subtitle (fastest, most reliable)
  // The header subtitle span[title] contains ALL member phones comma-separated
  const headerContacts = extractFromHeaderSubtitle();
  if (headerContacts && headerContacts.length > 0) {
    return { contacts: headerContacts, source: 'header' };
  }

  // STRATEGY 2: Open info panel and scrape participant rows
  await openInfoPanel();
  await sleep(800);

  const panel = document.querySelector('[data-testid="contact-info-drawer"]');
  if (panel) {
    // Scroll to load all members
    const scrollable = [...panel.querySelectorAll('*')].find(el => {
      const s = window.getComputedStyle(el);
      return (s.overflowY === 'scroll' || s.overflowY === 'auto') && el.scrollHeight > el.clientHeight + 30;
    }) || panel;

    scrollable.scrollTop = 0;
    await sleep(400);
    let prev = -1;
    for (let i = 0; i < 200; i++) {
      scrollable.scrollTop += 80;
      await sleep(80);
      if (scrollable.scrollTop === prev) break;
      prev = scrollable.scrollTop;
    }
    scrollable.scrollTop = 0;
    await sleep(500);

    // Collect phone-like spans from panel
    const phoneRe = /^\+?[\d][\d\s\-().]{4,20}$/;
    const phoneSpans = [...panel.querySelectorAll('span')]
      .filter(s => !s.children.length && phoneRe.test(s.innerText.trim()));

    if (phoneSpans.length > 0) {
      const seen = new Set();
      const contacts = [];
      for (const s of phoneSpans) {
        const phone = s.innerText.trim();
        // Try to get name from sibling/parent span
        const parent = s.closest('[data-testid="participant-list-item"]') ||
                       s.closest('[role="listitem"]') || s.parentElement;
        const nameSpan = parent ? [...parent.querySelectorAll('span')].find(ns =>
          ns !== s && !ns.children.length && ns.innerText.trim().length > 1 &&
          !phoneRe.test(ns.innerText.trim()) && ns.innerText.trim() !== 'You'
        ) : null;
        const name = nameSpan ? (nameSpan.getAttribute('title') || nameSpan.innerText.trim()) : '';
        if (!seen.has(phone)) { seen.add(phone); contacts.push({ name, phone }); }
      }
      return { contacts, source: 'panel' };
    }

    // Collect name-only spans
    const nameSpans = [...panel.querySelectorAll('span[title]')].filter(s => {
      const t = (s.getAttribute('title')||'').trim();
      return t.length > 1 && !phoneRe.test(t) && t !== 'You' &&
             !/^(Media|Links|Docs|Mute|Encryption|Disappearing|Starred|Add|Search|Report|Exit|Block|Notifications)$/i.test(t);
    });
    if (nameSpans.length > 0) {
      const seen = new Set();
      const contacts = [];
      for (const s of nameSpans) {
        const name = s.getAttribute('title').trim();
        if (!seen.has(name)) { seen.add(name); contacts.push({ name, phone: '' }); }
      }
      return { contacts, source: 'panel-names' };
    }
  }

  return { error: 'Could not extract contacts. Make sure you have a group chat open (not a private chat), then try again.' };
}

// ── Message Router ─────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
  if (req.action === 'scanGroups') {
    sendResponse({ groups: scanGroups() });
    return true;
  }
  if (req.action === 'extractFromGroup') {
    (async () => {
      const opened = await openChat(req.title);
      if (!opened) return sendResponse({ error: `Could not open "${req.title}". Click it manually then try again.` });
      await sleep(500);
      const result = await extractFromGroup(req.title);
      sendResponse(result);
    })();
    return true;
  }
});
