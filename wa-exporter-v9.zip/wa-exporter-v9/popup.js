// popup.js v9

let allGroups = [];
let selectedGroup = null;
let contacts = [];
let showGroupsOnly = false; // default ALL since group detection is limited

const scanBtn      = document.getElementById('scanBtn');
const groupSection = document.getElementById('groupSection');
const groupList    = document.getElementById('groupList');
const searchInput  = document.getElementById('searchInput');
const extractBtn   = document.getElementById('extractBtn');
const exportRow    = document.getElementById('exportRow');
const csvBtn       = document.getElementById('csvBtn');
const jsonBtn      = document.getElementById('jsonBtn');
const statusEl     = document.getElementById('status');
const previewEl    = document.getElementById('preview');
const tabGroups    = document.getElementById('tabGroups');
const tabAll       = document.getElementById('tabAll');
const s1=document.getElementById('s1'),s2=document.getElementById('s2'),s3=document.getElementById('s3');

function setStatus(msg, type='') { statusEl.textContent=msg; statusEl.className=type; }
function setStep(n) {
  [s1,s2,s3].forEach((el,i)=>{ el.className='step'+(i+1<n?' done':i+1===n?' active':''); });
}

tabGroups.addEventListener('click', () => {
  showGroupsOnly = true;
  tabGroups.className = 'ftab on'; tabAll.className = 'ftab';
  renderList();
});
tabAll.addEventListener('click', () => {
  showGroupsOnly = false;
  tabAll.className = 'ftab on'; tabGroups.className = 'ftab';
  renderList();
});

function getFiltered() {
  const q = searchInput.value.toLowerCase();
  return allGroups.filter(g =>
    g.title.toLowerCase().includes(q) && (!showGroupsOnly || g.isGroup || g.current)
  );
}

function renderList() {
  const list = getFiltered();
  groupList.innerHTML = '';
  if (!list.length) {
    groupList.innerHTML = `<div class="gitem"><span class="gname" style="color:#8696a0">${showGroupsOnly?'No groups detected — switch to All Chats':'No chats found'}</span></div>`;
    return;
  }
  list.forEach(g => {
    const div = document.createElement('div');
    div.className = 'gitem' + (selectedGroup === g.title ? ' selected' : '');
    const tag = g.current ? '<span class="gtag open">● Open now</span>'
              : g.isGroup ? '<span class="gtag grp">group</span>'
              : '<span class="gtag chat">chat</span>';
    div.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="#8696a0"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
      <span class="gname" title="${g.title}">${g.title}</span>${tag}`;
    div.addEventListener('click', () => selectGroup(g.title));
    groupList.appendChild(div);
  });
}

function selectGroup(title) {
  selectedGroup = title;
  extractBtn.disabled = false;
  extractBtn.className = 'ready';
  renderList();
  setStatus(`Selected: "${title}"`, 'ok');
  setStep(2);
}

searchInput.addEventListener('input', renderList);

scanBtn.addEventListener('click', async () => {
  scanBtn.disabled = true;
  setStatus('Scanning…');
  groupSection.style.display = 'none';
  exportRow.style.display = 'none';
  previewEl.style.display = 'none';
  contacts = []; selectedGroup = null;
  extractBtn.disabled = true; extractBtn.className = '';

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab.url.includes('web.whatsapp.com')) {
    setStatus('Please open WhatsApp Web first!', 'error');
    scanBtn.disabled = false; return;
  }

  chrome.tabs.sendMessage(tab.id, { action: 'scanGroups' }, resp => {
    scanBtn.disabled = false;
    if (chrome.runtime.lastError || !resp) {
      setStatus('Could not reach page. Refresh WhatsApp Web (Ctrl+Shift+R) then try again.', 'error'); return;
    }
    allGroups = resp.groups || [];
    if (!allGroups.length) {
      setStatus('No chats found. Make sure WhatsApp Web is loaded.', 'error'); return;
    }
    groupSection.style.display = 'block';
    // Default to "All Chats" tab since group icon detection varies
    showGroupsOnly = false;
    tabAll.className = 'ftab on'; tabGroups.className = 'ftab';
    renderList();
    const open = allGroups.find(g => g.current);
    setStatus(open
      ? `Found ${allGroups.length} chats · "${open.title}" is open ↓`
      : `Found ${allGroups.length} chats — pick your group below`, 'ok');
    setStep(2);
    if (open) selectGroup(open.title);
  });
});

extractBtn.addEventListener('click', async () => {
  if (!selectedGroup) return;
  extractBtn.disabled = true;
  exportRow.style.display = 'none';
  previewEl.style.display = 'none';
  contacts = [];
  setStatus(`Extracting from "${selectedGroup}"…`);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { action: 'extractFromGroup', title: selectedGroup }, resp => {
    extractBtn.disabled = false; extractBtn.className = 'ready';
    if (chrome.runtime.lastError || !resp) {
      setStatus('No response. Refresh WhatsApp Web and try again.', 'error'); return;
    }
    if (resp.error) { setStatus(resp.error, 'error'); return; }

    contacts = resp.contacts;
    const src = resp.source === 'header' ? ' (from member list)' : '';
    setStatus(`✓ ${contacts.length} contact${contacts.length!==1?'s':''}${src}`, 'ok');
    exportRow.style.display = 'flex';
    setStep(3);

    previewEl.style.display = 'block';
    previewEl.innerHTML = contacts.slice(0,10).map(c =>
      `<div class="prow"><span class="pname">${c.name||'(no name)'}</span><span class="pphone">${c.phone}</span></div>`
    ).join('') + (contacts.length>10?`<div class="prow" style="color:#00a884">…and ${contacts.length-10} more</div>`:'');
  });
});

function download(fn, content, mime) {
  const a = Object.assign(document.createElement('a'), {
    href: URL.createObjectURL(new Blob([content],{type:mime})), download: fn
  });
  a.click();
}
const safe = () => selectedGroup.replace(/[^a-z0-9]/gi,'_');
const toCSV = d => ['Name,Phone',...d.map(c=>`"${(c.name||'').replace(/"/g,'""')}","${(c.phone||'').replace(/"/g,'""')}"`).join('\n')];

csvBtn.addEventListener('click',()=>{ if(contacts.length) download(`${safe()}_contacts.csv`, ['Name,Phone',...contacts.map(c=>`"${(c.name||'').replace(/"/g,'""')}","${(c.phone||'').replace(/"/g,'""')}"`  )].join('\n'),'text/csv'); });
jsonBtn.addEventListener('click',()=>{ if(contacts.length) download(`${safe()}_contacts.json`,JSON.stringify(contacts,null,2),'application/json'); });
